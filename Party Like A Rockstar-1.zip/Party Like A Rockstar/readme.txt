v1.0

I do not claim any copyrights to the audio included with this beat-map

enjoy!